# Sign Language Detection > 2025-02-17 1:30am
https://universe.roboflow.com/devsecure/sign-language-detection-hv7gx

Provided by a Roboflow user
License: CC BY 4.0

